Tests are from [toml-test](https://github.com/BurntSushi/toml-test) and its forks.
