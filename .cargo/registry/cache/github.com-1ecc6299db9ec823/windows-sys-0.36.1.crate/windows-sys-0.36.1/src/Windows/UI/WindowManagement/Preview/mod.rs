pub type WindowManagementPreview = *mut ::core::ffi::c_void;
