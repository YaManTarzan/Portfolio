pub type HolographicKeyboard = *mut ::core::ffi::c_void;
