pub type DetectedFace = *mut ::core::ffi::c_void;
pub type FaceDetector = *mut ::core::ffi::c_void;
pub type FaceTracker = *mut ::core::ffi::c_void;
