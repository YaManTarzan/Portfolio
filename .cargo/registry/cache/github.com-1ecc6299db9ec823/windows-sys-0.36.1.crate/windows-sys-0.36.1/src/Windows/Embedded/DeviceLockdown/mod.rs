pub type DeviceLockdownProfileInformation = *mut ::core::ffi::c_void;
