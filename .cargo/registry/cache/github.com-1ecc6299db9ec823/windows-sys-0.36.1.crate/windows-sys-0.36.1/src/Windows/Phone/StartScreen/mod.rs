pub type DualSimTile = *mut ::core::ffi::c_void;
pub type IToastNotificationManagerStatics3 = *mut ::core::ffi::c_void;
