pub type InstalledClassicAppInfo = *mut ::core::ffi::c_void;
