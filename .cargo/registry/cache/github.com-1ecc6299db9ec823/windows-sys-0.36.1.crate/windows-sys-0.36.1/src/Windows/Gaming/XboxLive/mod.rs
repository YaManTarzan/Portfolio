#[cfg(feature = "Gaming_XboxLive_Storage")]
pub mod Storage;
