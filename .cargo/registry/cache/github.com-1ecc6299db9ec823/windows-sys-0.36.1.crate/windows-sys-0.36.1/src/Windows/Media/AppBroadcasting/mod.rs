pub type AppBroadcastingMonitor = *mut ::core::ffi::c_void;
pub type AppBroadcastingStatus = *mut ::core::ffi::c_void;
pub type AppBroadcastingStatusDetails = *mut ::core::ffi::c_void;
pub type AppBroadcastingUI = *mut ::core::ffi::c_void;
