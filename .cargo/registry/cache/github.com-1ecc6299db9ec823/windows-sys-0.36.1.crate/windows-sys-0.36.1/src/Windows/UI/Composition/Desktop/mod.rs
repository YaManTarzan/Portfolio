pub type DesktopWindowTarget = *mut ::core::ffi::c_void;
