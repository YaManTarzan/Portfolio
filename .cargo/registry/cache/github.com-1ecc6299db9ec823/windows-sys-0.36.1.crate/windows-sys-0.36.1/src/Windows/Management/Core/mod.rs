pub type ApplicationDataManager = *mut ::core::ffi::c_void;
