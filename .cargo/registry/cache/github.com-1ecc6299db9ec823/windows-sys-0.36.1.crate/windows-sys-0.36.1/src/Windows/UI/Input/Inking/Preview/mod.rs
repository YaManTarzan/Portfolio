pub type PalmRejectionDelayZonePreview = *mut ::core::ffi::c_void;
