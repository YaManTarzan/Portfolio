pub type AppExtension = *mut ::core::ffi::c_void;
pub type AppExtensionCatalog = *mut ::core::ffi::c_void;
pub type AppExtensionPackageInstalledEventArgs = *mut ::core::ffi::c_void;
pub type AppExtensionPackageStatusChangedEventArgs = *mut ::core::ffi::c_void;
pub type AppExtensionPackageUninstallingEventArgs = *mut ::core::ffi::c_void;
pub type AppExtensionPackageUpdatedEventArgs = *mut ::core::ffi::c_void;
pub type AppExtensionPackageUpdatingEventArgs = *mut ::core::ffi::c_void;
