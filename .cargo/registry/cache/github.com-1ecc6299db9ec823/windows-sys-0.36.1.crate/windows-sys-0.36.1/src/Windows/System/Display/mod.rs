pub type DisplayRequest = *mut ::core::ffi::c_void;
