pub type DataProtectionProvider = *mut ::core::ffi::c_void;
