pub type CoreAppWindowPreview = *mut ::core::ffi::c_void;
pub type SystemNavigationCloseRequestedPreviewEventArgs = *mut ::core::ffi::c_void;
pub type SystemNavigationManagerPreview = *mut ::core::ffi::c_void;
