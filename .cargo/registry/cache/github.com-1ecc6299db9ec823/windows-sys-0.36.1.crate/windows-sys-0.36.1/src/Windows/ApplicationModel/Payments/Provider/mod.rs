pub type PaymentAppCanMakePaymentTriggerDetails = *mut ::core::ffi::c_void;
pub type PaymentAppManager = *mut ::core::ffi::c_void;
pub type PaymentTransaction = *mut ::core::ffi::c_void;
pub type PaymentTransactionAcceptResult = *mut ::core::ffi::c_void;
