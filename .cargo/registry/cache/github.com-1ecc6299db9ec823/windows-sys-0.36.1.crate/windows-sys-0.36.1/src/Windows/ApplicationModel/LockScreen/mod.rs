pub type LockApplicationHost = *mut ::core::ffi::c_void;
pub type LockScreenBadge = *mut ::core::ffi::c_void;
pub type LockScreenInfo = *mut ::core::ffi::c_void;
pub type LockScreenUnlockingDeferral = *mut ::core::ffi::c_void;
pub type LockScreenUnlockingEventArgs = *mut ::core::ffi::c_void;
