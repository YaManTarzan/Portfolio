pub type CustomXamlResourceLoader = *mut ::core::ffi::c_void;
