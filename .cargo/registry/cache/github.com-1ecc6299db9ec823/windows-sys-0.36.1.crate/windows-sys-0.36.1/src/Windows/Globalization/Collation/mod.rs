pub type CharacterGrouping = *mut ::core::ffi::c_void;
pub type CharacterGroupings = *mut ::core::ffi::c_void;
