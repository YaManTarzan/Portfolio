pub type InstalledDesktopApp = *mut ::core::ffi::c_void;
