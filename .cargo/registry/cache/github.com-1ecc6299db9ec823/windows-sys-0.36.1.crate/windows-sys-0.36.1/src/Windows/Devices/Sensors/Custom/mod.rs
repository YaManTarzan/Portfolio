pub type CustomSensor = *mut ::core::ffi::c_void;
pub type CustomSensorReading = *mut ::core::ffi::c_void;
pub type CustomSensorReadingChangedEventArgs = *mut ::core::ffi::c_void;
