pub type IGraphicsEffect = *mut ::core::ffi::c_void;
pub type IGraphicsEffectSource = *mut ::core::ffi::c_void;
