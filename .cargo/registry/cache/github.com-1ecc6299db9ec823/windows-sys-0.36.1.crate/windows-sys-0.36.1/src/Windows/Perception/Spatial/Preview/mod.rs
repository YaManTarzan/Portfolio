pub type SpatialGraphInteropFrameOfReferencePreview = *mut ::core::ffi::c_void;
