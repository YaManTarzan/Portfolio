pub type ScreenReaderPositionChangedEventArgs = *mut ::core::ffi::c_void;
pub type ScreenReaderService = *mut ::core::ffi::c_void;
