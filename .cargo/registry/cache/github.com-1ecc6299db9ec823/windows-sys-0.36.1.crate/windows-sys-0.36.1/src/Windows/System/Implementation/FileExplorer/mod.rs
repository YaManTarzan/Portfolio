pub type ISysStorageProviderEventSource = *mut ::core::ffi::c_void;
pub type ISysStorageProviderHandlerFactory = *mut ::core::ffi::c_void;
pub type ISysStorageProviderHttpRequestProvider = *mut ::core::ffi::c_void;
pub type SysStorageProviderEventReceivedEventArgs = *mut ::core::ffi::c_void;
