pub type XsltProcessor = *mut ::core::ffi::c_void;
