pub type BackPressedEventArgs = *mut ::core::ffi::c_void;
pub type CameraEventArgs = *mut ::core::ffi::c_void;
