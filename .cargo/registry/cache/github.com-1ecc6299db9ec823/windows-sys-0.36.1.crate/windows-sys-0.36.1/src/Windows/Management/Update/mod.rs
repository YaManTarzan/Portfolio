pub type PreviewBuildsManager = *mut ::core::ffi::c_void;
pub type PreviewBuildsState = *mut ::core::ffi::c_void;
