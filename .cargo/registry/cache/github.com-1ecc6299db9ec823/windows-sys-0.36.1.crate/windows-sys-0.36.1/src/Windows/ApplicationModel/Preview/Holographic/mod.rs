pub type HolographicKeyboardPlacementOverridePreview = *mut ::core::ffi::c_void;
