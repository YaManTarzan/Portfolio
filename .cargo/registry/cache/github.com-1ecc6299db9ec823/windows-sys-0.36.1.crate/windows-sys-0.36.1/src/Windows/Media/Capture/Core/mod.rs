pub type VariablePhotoCapturedEventArgs = *mut ::core::ffi::c_void;
pub type VariablePhotoSequenceCapture = *mut ::core::ffi::c_void;
