pub type AtomPubClient = *mut ::core::ffi::c_void;
pub type ResourceCollection = *mut ::core::ffi::c_void;
pub type ServiceDocument = *mut ::core::ffi::c_void;
pub type Workspace = *mut ::core::ffi::c_void;
