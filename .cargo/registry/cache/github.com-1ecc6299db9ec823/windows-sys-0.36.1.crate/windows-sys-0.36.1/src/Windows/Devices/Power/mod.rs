pub type Battery = *mut ::core::ffi::c_void;
pub type BatteryReport = *mut ::core::ffi::c_void;
