pub type IPwmControllerProvider = *mut ::core::ffi::c_void;
pub type IPwmProvider = *mut ::core::ffi::c_void;
