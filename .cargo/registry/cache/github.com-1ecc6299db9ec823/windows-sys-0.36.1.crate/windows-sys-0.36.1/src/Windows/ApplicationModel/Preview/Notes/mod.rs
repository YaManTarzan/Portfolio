pub type NotePlacementChangedPreviewEventArgs = *mut ::core::ffi::c_void;
pub type NoteVisibilityChangedPreviewEventArgs = *mut ::core::ffi::c_void;
pub type NotesWindowManagerPreview = *mut ::core::ffi::c_void;
pub type NotesWindowManagerPreviewShowNoteOptions = *mut ::core::ffi::c_void;
