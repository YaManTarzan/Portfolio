pub type RemoteTextConnection = *mut ::core::ffi::c_void;
pub type RemoteTextConnectionDataHandler = *mut ::core::ffi::c_void;
