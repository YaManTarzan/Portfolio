pub type DeviceServicingDetails = *mut ::core::ffi::c_void;
pub type DeviceUseDetails = *mut ::core::ffi::c_void;
