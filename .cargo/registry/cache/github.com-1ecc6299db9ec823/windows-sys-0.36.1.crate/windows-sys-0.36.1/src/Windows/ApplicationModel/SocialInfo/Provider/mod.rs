pub type SocialDashboardItemUpdater = *mut ::core::ffi::c_void;
pub type SocialFeedUpdater = *mut ::core::ffi::c_void;
