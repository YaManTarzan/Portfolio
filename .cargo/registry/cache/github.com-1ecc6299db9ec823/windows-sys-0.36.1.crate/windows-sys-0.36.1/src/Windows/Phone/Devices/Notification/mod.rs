pub type VibrationDevice = *mut ::core::ffi::c_void;
