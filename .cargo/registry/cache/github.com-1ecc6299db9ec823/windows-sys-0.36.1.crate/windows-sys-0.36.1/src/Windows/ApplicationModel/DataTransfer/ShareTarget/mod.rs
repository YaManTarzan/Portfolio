pub type QuickLink = *mut ::core::ffi::c_void;
pub type ShareOperation = *mut ::core::ffi::c_void;
