pub type OcrEngine = *mut ::core::ffi::c_void;
pub type OcrLine = *mut ::core::ffi::c_void;
pub type OcrResult = *mut ::core::ffi::c_void;
pub type OcrWord = *mut ::core::ffi::c_void;
