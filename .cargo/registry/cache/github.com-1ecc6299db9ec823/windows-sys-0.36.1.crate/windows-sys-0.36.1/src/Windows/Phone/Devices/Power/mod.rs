pub type Battery = *mut ::core::ffi::c_void;
