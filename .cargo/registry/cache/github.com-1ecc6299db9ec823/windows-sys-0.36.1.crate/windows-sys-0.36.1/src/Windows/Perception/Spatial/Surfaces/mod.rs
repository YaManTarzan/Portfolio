pub type SpatialSurfaceInfo = *mut ::core::ffi::c_void;
pub type SpatialSurfaceMesh = *mut ::core::ffi::c_void;
pub type SpatialSurfaceMeshBuffer = *mut ::core::ffi::c_void;
pub type SpatialSurfaceMeshOptions = *mut ::core::ffi::c_void;
pub type SpatialSurfaceObserver = *mut ::core::ffi::c_void;
