pub type LanguageFont = *mut ::core::ffi::c_void;
pub type LanguageFontGroup = *mut ::core::ffi::c_void;
