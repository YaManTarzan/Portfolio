pub type PhoneCallOrigin = *mut ::core::ffi::c_void;
