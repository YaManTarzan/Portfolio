pub type FileInformation = *mut ::core::ffi::c_void;
pub type FileInformationFactory = *mut ::core::ffi::c_void;
pub type FolderInformation = *mut ::core::ffi::c_void;
pub type IStorageItemInformation = *mut ::core::ffi::c_void;
