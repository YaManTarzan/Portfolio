pub type OemSupportInfo = *mut ::core::ffi::c_void;
pub type SystemSupportDeviceInfo = *mut ::core::ffi::c_void;
