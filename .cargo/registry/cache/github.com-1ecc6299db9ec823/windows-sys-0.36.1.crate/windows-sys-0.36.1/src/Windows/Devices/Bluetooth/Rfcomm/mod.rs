pub type RfcommDeviceService = *mut ::core::ffi::c_void;
pub type RfcommDeviceServicesResult = *mut ::core::ffi::c_void;
pub type RfcommServiceId = *mut ::core::ffi::c_void;
pub type RfcommServiceProvider = *mut ::core::ffi::c_void;
