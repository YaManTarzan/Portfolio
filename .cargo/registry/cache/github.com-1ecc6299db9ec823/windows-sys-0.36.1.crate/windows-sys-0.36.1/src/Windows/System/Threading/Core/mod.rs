pub type PreallocatedWorkItem = *mut ::core::ffi::c_void;
pub type SignalHandler = *mut ::core::ffi::c_void;
pub type SignalNotifier = *mut ::core::ffi::c_void;
