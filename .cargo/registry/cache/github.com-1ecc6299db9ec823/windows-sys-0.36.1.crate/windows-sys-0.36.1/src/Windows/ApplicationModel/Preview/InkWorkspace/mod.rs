pub type InkWorkspaceHostedAppManager = *mut ::core::ffi::c_void;
