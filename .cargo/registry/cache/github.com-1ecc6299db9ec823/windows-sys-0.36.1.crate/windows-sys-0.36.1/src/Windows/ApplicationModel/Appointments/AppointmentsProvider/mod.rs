pub type AddAppointmentOperation = *mut ::core::ffi::c_void;
pub type RemoveAppointmentOperation = *mut ::core::ffi::c_void;
pub type ReplaceAppointmentOperation = *mut ::core::ffi::c_void;
