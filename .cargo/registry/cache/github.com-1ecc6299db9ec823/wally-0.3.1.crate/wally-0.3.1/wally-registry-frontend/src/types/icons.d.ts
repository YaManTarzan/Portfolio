export type IconsId =
  | "chevron"
  | "copy"
  | "discord"
  | "github"
  | "hamburger"
  | "instagram"
  | "linkedin"
  | "search"
  | "twitter"
  | "youtube";
