local OneDependency = require(script.Parent.OneDependency)

return function()
	return OneDependency()
end